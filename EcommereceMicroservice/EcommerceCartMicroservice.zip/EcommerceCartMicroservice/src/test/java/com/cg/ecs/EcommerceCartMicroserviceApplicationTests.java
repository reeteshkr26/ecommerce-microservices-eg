package com.cg.ecs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceCartMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
