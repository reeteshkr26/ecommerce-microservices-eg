package com.cg.ecs.entity;

public enum ProductType {

	ELECTRONICS,GROCERY,FURNITURE,FOODS,CLOTHES;
}
