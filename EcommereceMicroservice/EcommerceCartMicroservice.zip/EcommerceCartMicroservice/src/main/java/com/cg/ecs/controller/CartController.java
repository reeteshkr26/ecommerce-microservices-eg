package com.cg.ecs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ecs.exception.CartException;
import com.cg.ecs.model.CartModel;
import com.cg.ecs.service.CartService;


@RestController
@RequestMapping("/carts")
@CrossOrigin
public class CartController {

	@Autowired
	private CartService cartService;
	
	@PostMapping
	public ResponseEntity<CartModel> createProduct(@RequestBody CartModel cart) throws CartException{
		cart=cartService.addIntoCart(cart);
		return new ResponseEntity<>(cart,HttpStatus.OK);
	}
	@GetMapping("/{id}")
	public ResponseEntity<CartModel> findById(@PathVariable("id") Long cartId) {
		ResponseEntity<CartModel> response = null;

		CartModel cart = cartService.findById(cartId);

		if (cart == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(cart, HttpStatus.OK);
		}

		return response;
	}
}
