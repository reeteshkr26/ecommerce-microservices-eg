package com.cg.ecs.model;

import java.util.ArrayList;
import java.util.List;

import com.cg.ecs.entity.ProductType;

public class CartModel {
	private long cartId;
	private List<Long> productId = new ArrayList<Long>();
	//private long productId;
	private List<ProductModel> productList=new ArrayList<>();
	
	public List<ProductModel> getProductList() {
		return productList;
	}
	public void setProductList(List<ProductModel> productList) {
		this.productList = productList;
	}
	
	public long getCartId() {
		return cartId;
	}
	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public List<Long> getProductId() {
		return productId;
	}
	public void setProductId(List<Long> productId) {
		this.productId = productId;
	}
	
	/*private String productName;
	private double productPrice;
	private ProductType productType;
	private long productQuantity;
	

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	public long getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(long productQuantity) {
		this.productQuantity = productQuantity;
	}*/
	
	
	

}
