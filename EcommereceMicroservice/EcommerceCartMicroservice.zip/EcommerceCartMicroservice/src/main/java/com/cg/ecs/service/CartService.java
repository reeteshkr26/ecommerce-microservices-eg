package com.cg.ecs.service;

import java.util.List;

import com.cg.ecs.exception.CartException;
import com.cg.ecs.model.CartModel;

public interface CartService {
	public CartModel addIntoCart(CartModel cartModel) throws CartException;
	public CartModel findById(long cartId);
	public List<CartModel> findAllCarts();
}
