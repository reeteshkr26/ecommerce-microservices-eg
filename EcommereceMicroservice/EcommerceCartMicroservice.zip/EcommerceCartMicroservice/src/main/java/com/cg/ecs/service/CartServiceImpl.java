package com.cg.ecs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ecs.dao.CartRepo;
import com.cg.ecs.entity.CartEntity;
import com.cg.ecs.exception.CartException;
import com.cg.ecs.model.CartModel;
import com.cg.ecs.model.ProductModel;

@Service
public class CartServiceImpl implements CartService{
	@Autowired
	private EcommerceProductProxyService productProxyService;
	
	@Autowired
	private CartRepo cartRepo;

	
	private CartEntity of(CartModel source) {
		CartEntity result=null;
		if(source!=null) {
			result=new CartEntity();
			result.setCartId(source.getCartId());
			result.setProductId(source.getProductId());
		}
		return result;
	}
	private CartModel of(CartEntity source) {
		CartModel result=null;
		if(source!=null) {
			result=new CartModel();
			result.setCartId(source.getCartId());
			result.setProductId(source.getProductId());
			for(int i=0;i<source.getProductId().size();i++) {
				ProductModel product=productProxyService.getProduct(source.getProductId().get(i));
				if(product!=null) {
					result.getProductList().add(product);
				}
			}
		}
		return result;
	}

	@Override
	public CartModel addIntoCart(CartModel cartModel) throws CartException {
		
		if(cartModel!=null) {
			if(cartRepo.existsById(cartModel.getCartId())) {
				throw new CartException("There exists a product with the given ID");
			}
			else{
				cartModel=of(cartRepo.save(of(cartModel)));
			}
		}
		return cartModel;
	}

	@Override
	public CartModel findById(long cartId) {
		
		return of(cartRepo.findById(cartId).orElse(null));
	}

	@Override
	public List<CartModel> findAllCarts() {
		
		return null;
	}
	

}
