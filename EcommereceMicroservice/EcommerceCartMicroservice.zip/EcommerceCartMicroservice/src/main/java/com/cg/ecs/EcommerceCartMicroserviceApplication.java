package com.cg.ecs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.cg.ecs.service")
@EnableDiscoveryClient
public class EcommerceCartMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceCartMicroserviceApplication.class, args);
	}

}
