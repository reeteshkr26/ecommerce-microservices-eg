package com.cg.egm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceGatewayMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
