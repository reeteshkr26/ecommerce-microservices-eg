package com.cg.epm.entity;

public enum ProductType {
	ELECTRONICS,GROCERY,FURNITURE,FOODS,CLOTHES;

}
