package com.cg.epm.service;

import java.util.List;

import com.cg.epm.exception.ProductException;
import com.cg.epm.model.ProductModel;

public interface ProductService {

	public ProductModel addProduct(ProductModel product) throws ProductException;
	public ProductModel updateProduct(ProductModel product) throws ProductException;
	public List<ProductModel> findAll();
	public ProductModel findById(long id);
	public void deleteById(long id);
}
