package com.cg.epm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_table")
public class ProductEntity {
	
	@Id
	@Column(name="product_id")
	private long productId;
	
	@Column(name="product_name",nullable=false)
	private String productName;
	
	@Column(name="product_price",nullable=false)
	private double productPrice;
	
	@Column(name="product_type",nullable=false)
	private ProductType productType;
	
	@Column(name="product_quantity")
	private long productQuantity;
	
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	public long getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(long productQuantity) {
		this.productQuantity = productQuantity;
	}

}
