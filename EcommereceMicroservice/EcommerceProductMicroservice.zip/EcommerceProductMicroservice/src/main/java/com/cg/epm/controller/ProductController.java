package com.cg.epm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.epm.exception.ProductException;
import com.cg.epm.model.ProductModel;
import com.cg.epm.service.ProductService;

@RestController
@RequestMapping("/products")
@CrossOrigin
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@PostMapping
	public ResponseEntity<ProductModel> createProduct(@RequestBody ProductModel product) throws ProductException{
		product=productService.addProduct(product);
		return new ResponseEntity<>(product,HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<ProductModel>> getAllProducts(){
		
		return new ResponseEntity<>(productService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/{id:[0-9]{1,4}}")
	public ResponseEntity<ProductModel> findById(@PathVariable("id") Long productId) {
		ResponseEntity<ProductModel> response = null;

		ProductModel product = productService.findById(productId);

		if (product == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(product, HttpStatus.OK);
		}

		return response;
	}
	
	@PutMapping
	public ResponseEntity<ProductModel> updateProduct(@RequestBody ProductModel product) throws ProductException {
		product = productService.updateProduct(product);
		return new ResponseEntity<>(product, HttpStatus.OK);
	}
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<Void> deleteTrainee(@PathVariable("productId") long productId) {

		ResponseEntity<Void> response = null;

		ProductModel product = productService.findById(productId);

		if (product == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			productService.deleteById(productId);
			response = new ResponseEntity<>(HttpStatus.OK);
		}

		return response;
	}
}
