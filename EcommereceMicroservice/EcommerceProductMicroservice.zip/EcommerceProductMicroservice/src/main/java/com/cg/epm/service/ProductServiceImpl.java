package com.cg.epm.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.epm.dao.ProductRepo;
import com.cg.epm.entity.ProductEntity;
import com.cg.epm.exception.ProductException;
import com.cg.epm.model.ProductModel;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepo repo;
	
	private ProductModel of(ProductEntity source) {
		ProductModel result=null;
		if(source!=null) {
			result=new ProductModel();
			result.setProductId(source.getProductId());
			result.setProductName(source.getProductName());
			result.setProductPrice(source.getProductPrice());
			result.setProductType(source.getProductType());
			result.setProductQuantity(source.getProductQuantity());
		
		}
		return result;
	}
	private ProductEntity of(ProductModel source) {
		ProductEntity result=null;
		if(source!=null) {
			result=new ProductEntity();
			result.setProductId(source.getProductId());
			result.setProductName(source.getProductName());
			result.setProductPrice(source.getProductPrice());
			result.setProductType(source.getProductType());
			result.setProductQuantity(source.getProductQuantity());
		}
		return result;
	}
	@Override
	public ProductModel addProduct(ProductModel product) throws ProductException {
		if(product!=null) {
			if(repo.existsById(product.getProductId())) {
				throw new ProductException("There exists a product with the given ID");
			}
			else{
				product=of(repo.save(of(product)));
			}
		}
		return product;
	}
	@Override
	public ProductModel updateProduct(ProductModel product) throws ProductException {
		if(product!=null) {
			ProductModel oldTrainee=of(repo.findById(product.getProductId()).orElse(null));
			if(oldTrainee==null) {
				throw new ProductException("There does not exists a product with the given ID");
			}
			else {
				product=of(repo.save(of(product)));
			}
		}
		return product;
	}
	@Override
	public List<ProductModel> findAll() {
		
		return repo.findAll().stream().map(entity->of(entity)).collect(Collectors.toList());
	}
	@Override
	public ProductModel findById(long id) {
	
		return of(repo.findById(id).orElse(null));
	}
	@Override
	public void deleteById(long id) {
		repo.deleteById(id);
		
	}
}
