package com.cg.edm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceDiscoverMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
